// Adds "Opna leikskráningu ↗" / "Open game entry ↗" to Hydra's top menu frame (Hydra_nav.jsp), in the
// language chosen in the app (same site, so it can read the setting). Kept tiny on purpose: the app
// itself (hydra-ui.js) only loads on /IIHF_Core/hydra-ui.
(() => {
  let lang = 'is';
  try {
    lang = localStorage.getItem('hui.lang') === 'en' ? 'en' : 'is';
  } catch {
    /* private mode */
  }
  const b = document.createElement('a');
  b.href = '/IIHF_Core/hydra-ui?mode=main';
  b.target = '_blank';
  b.textContent = lang === 'en' ? 'Open game entry ↗' : 'Opna leikskráningu ↗';
  b.style.cssText =
    'position:fixed;right:12px;top:6px;z-index:9;padding:6px 12px;border-radius:999px;background:#0b4ea2;color:#fff;font:600 13px system-ui,sans-serif;text-decoration:none';
  document.body.appendChild(b);
})();
