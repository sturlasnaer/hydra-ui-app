// Adds "Open game entry ↗" to Hydra's top menu frame (Hydra_nav.jsp). Kept tiny on purpose:
// the app itself (hydra-ui.js) only loads on /IIHF_Core/hydra-ui.
(() => {
  const b = document.createElement('a');
  b.href = '/IIHF_Core/hydra-ui';
  b.target = '_blank';
  b.textContent = 'Open game entry ↗';
  b.style.cssText =
    'position:fixed;right:12px;top:6px;z-index:9;padding:6px 12px;border-radius:999px;background:#0b4ea2;color:#fff;font:600 13px system-ui,sans-serif;text-decoration:none';
  document.body.appendChild(b);
})();
